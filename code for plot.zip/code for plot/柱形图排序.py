# -*- coding: utf-8 -*-
"""
Created on Thu May 22 21:05:32 2025

@author: y
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May 22 17:43:38 2025

@author: y
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 读取数据
df = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\ppe-precision-sort.csv")

y_data = df["SARS_PPE"]
x_data = df["Representations"]

# 手动为每个表征指定颜色（示例颜色，可根据需要修改）
color_map = {
    "ECFP2": "#2983B1", "ECFP6": "#2983B1", "Daylight": "#2983B1", 
    "AVALON": "#2983B1", "RDKit2d": "#2983B1", "MACCS": "#2983B1",
    "ECFP4": "#2983B1", "XGB-PubChem": "#2983B1", "E3FP": "#2983B1",
    "Mordred": "#2983B1", "3DFP": "#2983B1", "SELFIES": "#2983B1"
}


# 确保所有表征都有对应的颜色
default_color = "#D37538"  # 未指定颜色时的默认值
colors = [color_map.get(name, default_color) for name in x_data]

# 绘制柱状图
plt.figure(figsize=(14, 6))

for i in range(len(x_data)):
    plt.bar(
        i, y_data[i], width=0.6, 
        color=colors[i],  # 使用手动指定的颜色
        edgecolor='black', alpha=0.8
    )

# 设置x轴标签和倾斜角度
plt.xticks(
    ticks=range(len(x_data)),
    labels=x_data,
    rotation=45,
    ha="right",
    rotation_mode="anchor",
    fontname="Arial",
    fontsize=9
)

# 添加图例
plt.bar(0, 0, color="#2983B1", label='Fixed Representation')
plt.bar(0, 0, color="#D37538", label='Learned Representation')
plt.legend(loc='upper right')

# =============================================================================
# # 增大Y轴范围
# y_max = max(y_data)
# plt.ylim(0, y_max * 1.15)
# =============================================================================



# 其他设置
plt.xlabel("Representations", fontname="Arial", fontsize=12)
plt.ylabel("SARS_PPE Precision", fontname="Arial", fontsize=12)
plt.tight_layout()

# 保存并显示图表
plt.savefig("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\ppe柱形图_custom_color.png", 
            dpi=600, bbox_inches="tight")
plt.show()