# 加载必要的库
library(fmsb)

# 设置数据
data <- as.data.frame(rbind(
  c(17, 17, 17, 17, 17),   # 最大值
  c(0, 0, 0, 0, 0),   # 最小值
  c(9.9917426,	9.938498086,	10.18981251,	9.873959565,	6.067297075),   # 第二组数据
  c(10.16861031,	9.855610426,	8.621196596,	5.182516121,	8.292692529),   # 第四组数据
  c(9.208983261,	12.31804422,	12.16389354,	3.871445181,	0.570989369),
  c(7.268188213,	8.110370972,	11.84804059,	12.35886621,	13.4574785),   # 第三组数据
  c(6.545668954,	10.81842117,	14.84377286,	14.84377286,	16.63553233)   # 第一组数据http://127.0.0.1:46145/graphics/plot_zoom_png?width=1707&height=890
))

# 设置标签
colnames(data) <- c("FreeSolv\nDatasize 642",	"ESOL\nDatasize 1128",	"Lipophilicity\nDatasize 4200",	"QM8\nDatasize 21786","QM9\nDatasize 133885")
rownames(data) <- c("max", "min","UniMol", "KANO", "KPGT",	"XGB-Mordred","BAN")

# 设置雷达图的属性
radarchart(data, 
           axistype = 1,
           pcol = c("#BF0000", "#DC4800","#6A3D9A","#238B45","#3469AF"), # 不同组数据使用不同颜色
           pfcol = c(rgb(220/255, 101/255, 91/255, 0.2),  # 半透明填充颜色 (蓝色，透明度 0.5)
                     rgb(231/255, 132/255, 85/255, 0.2),  # 半透明填充颜色 (橙色，透明度 0.5)
                     rgb(247/255, 196/255, 118/255, 0.2), # 半透明填充颜色 (黄色，透明度 0.5)
                     rgb(153/255, 210/255, 213/255, 0.2), # 半透明填充颜色 (绿色，透明度 0.5)
                     rgb(105/255, 179/255, 200/255, 0.2)),
           #pfcol = c(NA, NA), # 不填充多边形区域
           plty = 1, # 使用实线http://127.0.0.1:46145/graphics/plot_zoom_png?width=1707&height=890
           plwd = 4, #线的粗细
           cglcol = "grey70",  # 设置背景线为黑色，或其他深色
           cglty = 1,         # 保持背景线为实线
           cglwd = 2, # 增加背景线的粗细
           axislabcol = "black", 
           vlcex = 0.75,# 控制顶点标签大小和距离图形的距离（数值越小，距离越远）
           
           caxislabels = c(0, 5, 10, 15, 17),
           title = "Different Datasize(US)")

# 添加图例
legend(x = "bottomright", 
       legend = c("KANO",	"XGB Mordred","BAN","KPGT", "UniMol"), 
       col = c("#BF0000", "#DC4800","#6A3D9A","#238B45","#3469AF"), 
       lwd = 5, 
       x.intersp = 0.5,
       bty = "n", 
       pch = 16, 
       pt.cex = 1.5,
       xpd = TRUE, # 允许图例绘制在图外
       inset = c(-0.15, 0.05))# 适当调整偏移量

