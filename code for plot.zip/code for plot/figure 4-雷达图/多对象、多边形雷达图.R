# 加载必要的库
library(fmsb)

# 设置数据
data <- as.data.frame(rbind(
  c(17, 17, 17, 17,17,17,17),   # 最大值
  c(0, 0, 0, 0,0,0,0),   # 最小值
  c(11.84804059,	1.118734209,	0.829275938,	7.020126933,	11.95080032,	6.675605375,	12.01793963),   # 第一组数据
  c(3.555836402,	14.84377286,	16.63553233,	14.06101352,	6.767412925,	5.358303886,	12.4123549),   # 第二组数据
  c(6.283927354,	9.873959565,	6.067297075,	8.862358653,	10.78764951,	4.840920862,	10.63164527),   # 第三组数据
  c(4.355001777,	12.35886621,	13.4574785,	13.22191243,	10.55445563,	6.746549467,	8.358501699),   # 第四组数据
  c(4.355001777,	12.35886621,	13.4574785,	13.22191243,	10.55445563,	6.746549467,	8.358501699)
))

# 设置标签
colnames(data) <- c("ClinTox\nTask number=2",	"QM8\nTask number=12",	"QM9\nTask number=12",	"Tox21\nTask number=12","MUV\nTask number=17","SIDER\nTask number=27","ToxCast\nTask number=617")
rownames(data) <- c("max", "min", "SVM-AVALON",	"Unimol",	"KANO",	"KPGT",	"molformer")

# 设置雷达图的属性
radarchart(data, 
           axistype = 1,
           pcol = c("#FAE48BB2", "#F8BAD0B2","#91D1C2FF","#4B8AD6B2","#6B58EEB2"), # 不同组数据使用不同颜色
           pfcol = c("#FAE48B66", "#F8BAD066","#91D1C266","#4B8AD666","#6B58EE66"), # 半透明填充颜色
           #pfcol = c(NA, NA), # 不填充多边形区域
           plty = 1, # 使用实线
           plwd = 2,
           cglcol = "grey", 
           cglty = 1,
           axislabcol = "black", 
           caxislabels = c(0, 5, 10, 15, 17),
           title = "Multi Label_US")

# 添加图例
legend(x = "bottomright", 
       legend = c("SVM-AVALON",	"Unimol",	"KANO",	"KPGT",	"molformer"), 
       col = c("#FAE48BB2", "#F8BAD0B2","#91D1C2FF","#4B8AD6B2","#6B58EEB2"), 
       lwd = 2, 
       bty = "n", 
       pch = 16, 
       pt.cex = 1.5,
       xpd = TRUE, # 允许图例绘制在图外
       inset = c(-0.3, -0.1))# 适当调整偏移量

