# 加载必要的库
library(fmsb)

# 设置数据
data <- as.data.frame(rbind(
  c(1, 1, 1, 1),   # 最大值
  c(0, 0, 0, 0),   # 最小值
  c(0.432389123,	0.482308157,	0.526115403,	0.107968366),   # 第一组数据
  c(0.44557823,	0.478169767,	0.524861839,	0.090691982),   # 第二组数据
  c(0.48856,	0.434303467,	0.4783,	0.11618),   # 第三组数据
  
  c(0.001,	0.693483709,	0.736932739,	0.012564706),
  c(0.001,	0.821445712,	0.726851146,	0.058823529)
))

# 设置标签
colnames(data) <- c("ToxCast\n(Neg/Pos:1-10)",	"	HIV\n(Neg/Pos:10-50)",	"	Tox21\n(Neg/Pos:10-50)",	"	MUV\n(Neg/Pos>50)")
rownames(data) <- c("max", "min","KPGT", "UniMol", "SVM AVALON","	N-Gram XGB",	"N-Gram RF")

# 设置雷达图的属性
radarchart(data, 
           axistype = 1,
           pcol = c("#BF0000", "#DC4800","#6A3D9A","#238B45","#3469AF"), # 不同组数据使用不同颜色
           pfcol = c(rgb(220/255, 101/255, 91/255, 0.2),  # 半透明填充颜色 (蓝色，透明度 0.5)
                     rgb(231/255, 132/255, 85/255, 0.2),  # 半透明填充颜色 (橙色，透明度 0.5)
                     rgb(247/255, 196/255, 118/255, 0.2), # 半透明填充颜色 (黄色，透明度 0.5)
                     rgb(153/255, 210/255, 213/255, 0.2), # 半透明填充颜色 (绿色，透明度 0.5)
                     rgb(105/255, 179/255, 200/255, 0.2)),
           #pfcol = c(NA, NA), # 不填充多边形区域
           plty = 1, # 使用实线
           plwd = 4, #线的粗细
           cglcol = "grey70",  # 设置背景线为黑色，或其他深色
           cglty = 1,         # 保持背景线为实线
           cglwd = 2, # 增加背景线的粗细
           axislabcol = "black", 
           vlcex = 0.7,# 控制顶点标签大小和距离图形的距离（数值越小，距离越远）
           caxislabels = c(0, 0.25, 0.5, 0.75, 1),
           title = "Unbalanced Task(AUPR)")

# 添加图例
legend(x = "bottomright", 
       legend = c("KPGT", "UniMol", "SVM AVALON","	N-Gram XGB",	"N-Gram RF"), 
       col = c("#BF0000", "#DC4800","#6A3D9A","#238B45","#3469AF"), 
       lwd = 5, 
       x.intersp = 0.5, 
       bty = "n", 
       pch = 16, 
       pt.cex = 1.5,
       xpd = TRUE, # 允许图例绘制在图外
       inset = c(-0.1, -0.1))# 适当调整偏移量

