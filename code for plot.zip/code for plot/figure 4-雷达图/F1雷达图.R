# 加载必要的库
library(fmsb)

# 设置数据
data <- as.data.frame(rbind(
  c(0.5, 0.5, 0.5, 0.5),   # 最大值
  c(0, 0, 0, 0),   # 最小值
  c(0.4028,	0.2476,	0.0628,	0.3406),   # 第四组数据
  c(0.344948889,	0.451053786,	0.02842,	0.4546),
  
  c(0.326442342,	0.498273734,	0.013333333,	0.475068918),
  c(0.33482528,	0.484551936,	0.065359477,	0.433994968),
  c(0.39312,	0.469926725,	0.07088,	0.45922)
))

# 设置标签
colnames(data) <- c("ToxCast\n(Neg/Pos:1-10)",	"	HIV\n(Neg/Pos:10-50)",	"	Tox21\n(Neg/Pos:10-50)",	"	MUV\n(Neg/Pos>50)")
rownames(data) <- c("max", "min","Trimnet","SVM MACCS","UniMol","KANO","SVM AVALON")

# 设置雷达图的属性
radarchart(data, 
           axistype = 1,
           pcol = c("#BF0000", "#DC4800","#6A3D9A","#238B45","#3469AF"), # 不同组数据使用不同颜色
           pfcol = c(rgb(220/255, 101/255, 91/255, 0.2),  # 半透明填充颜色 (蓝色，透明度 0.5)
                     rgb(231/255, 132/255, 85/255, 0.2),  # 半透明填充颜色 (橙色，透明度 0.5)
                     rgb(247/255, 196/255, 118/255, 0.2), # 半透明填充颜色 (黄色，透明度 0.5)
                     rgb(153/255, 210/255, 213/255, 0.2), # 半透明填充颜色 (绿色，透明度 0.5)
                     rgb(105/255, 179/255, 200/255, 0.2)),
           #pfcol = c(NA, NA), # 不填充多边形区域
           plty = 1, # 使用实线
           plwd = 4, #线的粗细
           cglcol = "grey70",  # 设置背景线为黑色，或其他深色
           cglty = 1,         # 保持背景线为实线
           cglwd = 2, # 增加背景线的粗细
           axislabcol = "black", 
           vlcex = 0.7,# 控制顶点标签大小和距离图形的距离（数值越小，距离越远）
           caxislabels = c(0, 0.2, 0.3, 0.4, 0.5),
           title = "Unbalanced Task(F1)")

# 添加图例
legend(x = "bottomright", 
       legend = c("Trimnet","SVM MACCS","UniMol","KANO","SVM AVALON"), 
       col = c("#BF0000", "#DC4800","#6A3D9A","#238B45","#3469AF"), 
       lwd = 5, 
       x.intersp = 0.5, 
       bty = "n", 
       pch = 16, 
       pt.cex = 1.5,
       xpd = TRUE, # 允许图例绘制在图外
       inset = c(-0.1, -0.1))# 适当调整偏移量

