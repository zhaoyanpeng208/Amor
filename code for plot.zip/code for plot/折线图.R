# 设置绘图区域，右边留出足够的空间
par(mar = c(9, 4, 7, 5), xpd = TRUE)

library(readxl)
data <- read_excel("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\特殊数据集\\不均衡-recall.xlsx")
# 提取行名（比较对象）和列名（点）
row_names <- data[[1]]  # 第一列是比较对象名称
data_values <- data[, -1]  # 其余的列是数值数据

# 确定X轴标签（列名或点的编号）
#x_labels <- colnames(data_values)
#x_labels <- c(2,2,2,12,17,27,617)#多任务
x_labels <- c("1~10","10~50","10~50",">50")#不均衡
x_toplabels <- colnames(data_values)

# 确保数据没有 NA 值
data_values <- na.omit(data_values)

# 设置颜色
line_colors <- rainbow(nrow(data_values))  # 给每条线分配不同颜色

# 绘制空图，为折线图设置范围
plot(1:ncol(data_values), data_values[1, ], type = "n", ylim = range(data_values), 
     xaxt = "n", xlab = "Neg/Pos ratio", ylab = "Recall")
# 添加图形标题，并通过line参数调整标题的位置
title("Top 5 representations for sample unbalanced task", line = 3.5)  # 增大line值，使标题上移

# 设置X轴标签
axis(1, at = 1:ncol(data_values), labels = x_labels)
# 添加顶部的第二X轴标签
axis(3, at = 1:ncol(data_values), labels = x_toplabels,mgp = c(3, 0.5, 0))  # 顶部X轴标签
# 添加顶部X轴的标题
mtext("multi-label datasets", side = 3, line = 2) 

# 绘制多条线
for (i in 1:nrow(data_values)) {
  lines(1:ncol(data_values), data_values[i, ], type = "b", col = line_colors[i], pch = 16, lwd = 2)
}

# 添加图例
legend("bottom", bty = "n", inset = c(0, -0.93), legend = row_names, col = line_colors, lty = 1, lwd = 2, pch = 16,ncol=2)
