# -*- coding: utf-8 -*-
"""
Created on Mon May 26 17:08:13 2025

@author: y
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May 22 21:05:32 2025

@author: y
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 设置中文字体支持
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]

def plot_data(ax, x_data, y_data, title, y_label, label):
    """绘制单个子图的函数"""
    # 手动为每个表征指定颜色（示例颜色，可根据需要修改）
    color_map = {
        "ECFP2": "#2983B1", "ECFP6": "#2983B1", "Daylight": "#2983B1", 
        "AVALON": "#2983B1", "RDKit2d": "#2983B1", "MACCS": "#2983B1",
        "ECFP4": "#2983B1", "XGB-PubChem": "#2983B1", "E3FP": "#2983B1",
        "Mordred": "#2983B1", "3DFP": "#2983B1", "SELFIES": "#2983B1"
    }
    
    # 确保所有表征都有对应的颜色
    default_color = "#D37538"  # 未指定颜色时的默认值
    colors = [color_map.get(name, default_color) for name in x_data]

    # 绘制柱状图
    for i in range(len(x_data)):
        ax.bar(
            i, y_data[i], width=0.6, 
            color=colors[i],  # 使用手动指定的颜色
            edgecolor='black', alpha=0.8
        )

    # 设置x轴标签和倾斜角度
    ax.set_xticks(range(len(x_data)))
    ax.set_xticklabels(x_data, rotation=45, ha="right", rotation_mode="anchor", 
                      fontname="Arial", fontsize=7)

    # 添加图例
    ax.bar(0, 0, color="#2983B1", label='Fixed Representation')
    ax.bar(0, 0, color="#D37538", label='Learned Representation')
    ax.legend(loc='upper right', fontsize=7)

    # 增大Y轴范围
    y_max = max(y_data)
    ax.set_ylim(0, y_max * 1.1)  # Y轴上限设为数据最大值的1.1倍

    # 添加子图标签 a, b, c, d
    ax.text(-0.1, 1.05, label, transform=ax.transAxes, fontsize=12,
            fontweight='bold', va='top', ha='right')
    
    # 其他设置
    ax.set_title(title, fontname="Arial", fontsize=10, pad=10)
    ax.set_xlabel("Representation Methods", fontname="Arial", fontsize=9)
    ax.set_ylabel(y_label, fontname="Arial", fontsize=9)
    # ax.grid(axis='y', linestyle='--', alpha=0.7)  # 不显示虚线

# 读取数据（确保路径正确）
# 这里假设其他三个文件的结构与SARS_PPE相同，列名可能需要调整
df_sars = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\alpha-precision-sort.csv")
df_hek = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\cpe-precision-sort.csv")
df_caco = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\HEK293-precision-sort.csv")
df_mdc = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\ppe-precision-sort.csv")

# 提取数据
x_data = df_sars["Representations"]  # 假设所有图的x轴标签相同
y_sars = df_sars["SARS_Alpha"]
y_hek = df_hek["SARS_CPE"]  # 假设列名类似，需要根据实际情况调整
y_caco = df_caco["HEK293"]
y_mdc = df_mdc["SARS_PPE"]

# 创建一个2x2的子图画布
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
plt.subplots_adjust(hspace=0.5, wspace=0.3)  # 调整子图间距

# 在每个子图上绘制数据，并添加标签 a, b, c, d
plot_data(axes[0, 0], x_data, y_sars, "SARS_Alpha Dataset", "Precision", "a")
plot_data(axes[0, 1], x_data, y_hek, "SARS_CPE Dataset", "Precision", "b")
plot_data(axes[1, 0], x_data, y_caco, "HEK293 Dataset", "Precision", "c")
plot_data(axes[1, 1], x_data, y_mdc, "SARS_PPE Dataset", "Precision", "d")

# 保存并显示图表
plt.savefig("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\all_precision_sort.png", 
            dpi=600, bbox_inches="tight")
plt.show()