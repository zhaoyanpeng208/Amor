
library(tidyverse)
library(funkyheatmap)
library(kableExtra)

data<-read.table(file='F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\热图复刻数据-2-标准化.csv',header=TRUE,row.names= NULL,sep=',')
head(data)

# 构造一个函数将排名在3名之外的赋值为空
label_top_3 <- function(scores, ...) {
  ranks <- rank(scores, ...)
  ifelse(ranks <= 3, as.character(ranks), "")
}

data  %>% 
  mutate(id = as.character(1:n()),
         Type = factor(Type, 
                       levels = c("Fixed", "Learned"), 
                       labels = c("Fixed", "Learned"))
  )  %>%
  
  # Create rank labels
  mutate(label_All_USI = label_top_3(rank_All_USI),
         label_Physiology_USI = label_top_3(rank_Physiology_USI),
         label_Biophysics_USI = label_top_3(rank_Biophysics_USI),
         label_Physical_chemistry_USI = label_top_3(rank_Physical_chemistry_USI),
         label_Quantum_mechanics_USI = label_top_3(rank_Quantum_mechanics_USI),
         label_SARS_CoV_USI = label_top_3(rank_SARS_CoV_USI),
         label_precision = label_top_3(rank_precision),
         label_recall = label_top_3(rank_recall),
         label_f1 = label_top_3(rank_f1),
         label_muti_task_USI = label_top_3(rank_muti_task_USI),
         label_sample_size_USI = label_top_3(rank_sample_size_USI)
  ) %>% 
  # scale rank columns between [0, 1] because `scale_column` is set to FALSE.
  mutate(across(c("rank_All_USI", "rank_Physiology_USI", "rank_Biophysics_USI", "rank_Physical_chemistry_USI", "rank_Quantum_mechanics_USI", "rank_SARS_CoV_USI", "rank_precision", "rank_recall", "rank_f1", "rank_muti_task_USI", "rank_sample_size_USI"),
                ~scale_minmax(-.x))) %>% 
  as_tibble() -> data_plot


column_info <- tribble(# tribble_start
  ~id,                   ~id_color,                   ~name,    ~geom,         ~group,                                                      ~options,
  "id",                          NA,                  "Index",   "text",       "Method",                                               list(hjust = 0),
  "method",                          NA,                "Method",   "text",       "Method",                                    list(hjust = 0, width = 5),
  "Type",                  "Type",              "Representation Type",   "text",       "Method",                         list(palette = "features", width = 2),
  "All_USI",             "rank_All_USI",              "All_USI",    "bar",          "Universality",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_All_USI",                          NA,                      NA,   "text",          "Universality",                              list(hjust = .1, overlay = TRUE),
  "Physiology_USI",           "rank_Physiology_USI",                  "Physiology_USI",    "bar",          "Task_Adaptability",    list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_Physiology_USI",                          NA,                      NA,   "text",          "Task_Adaptability",                              list(hjust = .1, overlay = TRUE),
  "Biophysics_USI",      "rank_Biophysics_USI",        "Biophysics_USI",    "bar",          "Task_Adaptability",    list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_Biophysics_USI",                          NA,                      NA,   "text",          "Task_Adaptability",                              list(hjust = .1, overlay = TRUE),
  "Physical_chemistry_USI",  "rank_Physical_chemistry_USI",  "Physical_chemistry_USI",    "bar",          "Task_Adaptability",    list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_Physical_chemistry_USI",                          NA,                      NA,   "text",          "Task_Adaptability",                              list(hjust = .1, overlay = TRUE),
  "Quantum_mechanics_USI",          "rank_Quantum_mechanics_USI",           "Quantum_mechanics_USI",    "bar",          "Task_Adaptability",    list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_Quantum_mechanics_USI",                          NA,                      NA,   "text",          "Task_Adaptability",                              list(hjust = .1, overlay = TRUE),
  "SARS_CoV_USI",      "rank_SARS_CoV_USI",                 "SARS-CoV-2_USI",    "bar",  "Task_Adaptability",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_SARS_CoV_USI",                          NA,                      NA,   "text",  "Task_Adaptability",                              list(hjust = .1, overlay = TRUE),
  "precision",        "rank_precision",                 "Precision",    "bar",  "Unbalanced",   list(palette = "oranges", width = 1.5, draw_outline = FALSE),
  "label_precision",                          NA,                      NA,   "text",  "Unbalanced",                              list(hjust = .1, overlay = TRUE),
  "recall",             "rank_recall",              "Recall",    "bar",          "Unbalanced",    list(palette = "oranges", width = 1.5, draw_outline = FALSE),
  "label_recall",                          NA,                      NA,   "text",          "Unbalanced",                              list(hjust = .1, overlay = TRUE),
  "f1",           "rank_f1",                  "F1",    "bar",          "Unbalanced",    list(palette = "oranges", width = 1.5, draw_outline = FALSE),
  "label_f1",                          NA,                      NA,   "text",          "Unbalanced",                              list(hjust = .1, overlay = TRUE),
  "muti_task_USI",      "rank_muti_task_USI",        "muti_task_USI",    "bar",          "Muti_Task",    list(palette = "greys", width = 1.5, draw_outline = FALSE),
  "label_muti_task_USI",                          NA,                      NA,   "text",          "Muti_Task",                              list(hjust = .1, overlay = TRUE),
  "sample_size_USI",  "rank_sample_size_USI",  "sample_size_USI",    "bar",          "Sample_Size",    list(palette = "purples", width = 1.5, draw_outline = FALSE),
  "label_sample_size_USI",                          NA,                      NA,   "text",          "Sample_Size",                              list(hjust = .1, overlay = TRUE),
)

column_info


column_groups <- tribble(
  ~ group,     ~ palette,      ~ level1,
  "Method",       "black",      "Method",
  "Universality",  "blues",  "Universality",
  "Task_Adaptability", "greens", "Task_Adaptability",
  "Unbalanced", "oranges", "Unbalanced",
  "Muti_Task",       "greys",         "Muti_Task",
  "Sample_Size", "purples", "Sample_Size"
)

row_info <- tibble(id = data_plot$id, 
                   group = NA_character_)


palettes <- list(
  Type = c(Fixed = "#4c4c4c", Learned = "#006600"),
  blues = "Blues",
  greens = "Greens",
  oranges = rev(RColorBrewer::brewer.pal(9, "Oranges")),
  greys = "Greys",
  #reds = "Reds",
  purples = rev(RColorBrewer::brewer.pal(9, "Purples")),
  black = c("black", "black")
)



legends <- list(
  list(
    title = "Universality rank",
    palette = "blues",
    geom = "rect",
    labels = c("40", " ", "30", " ", "20"," ", "10", " ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Task Adaptability rank",
    palette = "greens",
    geom = "rect",
    labels = c("40", " ", "30", " ", "20"," ", "10", " ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Unbalanced rank",
    palette = "oranges",
    geom = "rect",
    labels = c("40", " ", "30", " ", "20"," ", "10", " ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Muti-Task rank",
    palette = "greys",
    geom = "rect",
    labels = c("40", " ", "30", " ", "20"," ", "10", " ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Sample Size rank",
    palette = "purples",
    geom = "rect",
    labels = c("40", " ", "30", " ", "20"," ", "10", " ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  )
)



## 作图
funky_heatmap(
  data = data_plot,
  column_info = column_info,
  column_groups = column_groups,
  row_info = row_info,
  palettes = palettes,
  legends = legends,
  position_args = position_arguments(
    col_annot_offset = 4
  ),
  scale_column = FALSE
)




