
library(tidyverse)
library(funkyheatmap)
library(kableExtra)

data<-read.table(file='F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\热图复刻数据-归一化.csv',header=TRUE,row.names= NULL,sep=',')
head(data)

# 构造一个函数将排名在3名之外的赋值为空
label_top_3 <- function(scores, ...) {
  ranks <- rank(scores, ...)
  ifelse(ranks <= 3, as.character(ranks), "")
}

data  %>% 
  mutate(id = as.character(1:n()),
         Type = factor(Type, 
                          levels = c("string", "fingerprint","descriptors","graph","Graph+geometry","image","geometry"), 
                          labels = c("string", "fingerprint","descriptors","graph","Graph+geometry","image","geometry"))
         )  %>%
   
  # Create rank labels
  mutate(label_bbbp = label_top_3(rank_bbbp),
         label_clintox = label_top_3(rank_clintox),
         label_sider = label_top_3(rank_sider),
         label_tox21 = label_top_3(rank_tox21),
         label_toxcast = label_top_3(rank_toxcast),
         label_bace = label_top_3(rank_bace),
         label_hiv = label_top_3(rank_hiv),
         label_muv = label_top_3(rank_muv),
         label_esol = label_top_3(rank_esol),
         label_freesolv = label_top_3(rank_freesolv),
         label_lipophilicity = label_top_3(rank_lipophilicity),
         label_qm8 = label_top_3(rank_qm8),
         label_qm9 = label_top_3(rank_qm9),
         label_sars_alpha = label_top_3(rank_sars_alpha),
         label_sars_cpe = label_top_3(rank_sars_cpe),
         label_hek293 = label_top_3(rank_hek293),
         label_sars_ppe = label_top_3(rank_sars_ppe)
         ) %>% 
  # scale rank columns between [0, 1] because `scale_column` is set to FALSE.
  mutate(across(c("rank_bbbp", "rank_clintox", "rank_sider", "rank_tox21", "rank_toxcast", "rank_bace", "rank_hiv", "rank_muv", "rank_esol", "rank_freesolv", "rank_lipophilicity","rank_qm8","rank_qm9","rank_sars_alpha","rank_sars_cpe","rank_hek293","rank_sars_ppe"),
                ~scale_minmax(-.x))) %>% 
  as_tibble() -> data_plot


column_info <- tribble(# tribble_start
  ~id,                   ~id_color,                   ~name,    ~geom,         ~group,                                                      ~options,
  "id",                          NA,                  "Index",   "text",       "Method",                                               list(hjust = 0),
  "method",                          NA,                "Method",   "text",       "Method",                                    list(hjust = 0, width = 5),
  "Type",                  "Type",              "Representation Type",   "text",       "Method",                         list(palette = "features", width = 2),
  "overall_bbbp",             "rank_bbbp",              "BBBP",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_bbbp",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_clintox",           "rank_clintox",                  "ClinTox",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_clintox",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_sider",      "rank_sider",        "SIDER",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_sider",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_tox21",  "rank_tox21",  "Tox21",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_tox21",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_toxcast",          "rank_toxcast",           "ToxCast",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_toxcast",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_bace",      "rank_bace",                 "BACE",    "bar",  "US",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_bace",                          NA,                      NA,   "text",  "US",                              list(hjust = .1, overlay = TRUE),
  "overall_hiv",        "rank_hiv",                 "HIV",    "bar",  "US",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_hiv",                          NA,                      NA,   "text",  "US",                              list(hjust = .1, overlay = TRUE),
  "overall_muv",             "rank_muv",              "MUV",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_muv",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_esol",           "rank_esol",                  "ESOL",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_esol",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_freesolv",      "rank_freesolv",        "FreeSolv",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_freesolv",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_lipophilicity",  "rank_lipophilicity",  "Lipophilicity",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_lipophilicity",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_qm8",          "rank_qm8",           "QM8",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_qm8",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_qm9",      "rank_qm9",                 "QM9",    "bar",  "US",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_qm9",                          NA,                      NA,   "text",  "US",                              list(hjust = .1, overlay = TRUE),
  "overall_sars_alpha",        "rank_sars_alpha",                 "SARS_Alpha",    "bar",  "US",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_sars_alpha",                          NA,                      NA,   "text",  "US",                              list(hjust = .1, overlay = TRUE),
  "overall_sars_cpe",          "rank_sars_cpe",           "SARS_CPE",    "bar",          "US",    list(palette = "blues", width = 1.5, draw_outline = FALSE),
  "label_sars_cpe",                          NA,                      NA,   "text",          "US",                              list(hjust = .1, overlay = TRUE),
  "overall_hek293",      "rank_hek293",                 "HEK293",    "bar",  "US",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_hek293",                          NA,                      NA,   "text",  "US",                              list(hjust = .1, overlay = TRUE),
  "overall_sars_ppe",        "rank_sars_ppe",                 "SARS_PPE",    "bar",  "US",   list(palette = "greens", width = 1.5, draw_outline = FALSE),
  "label_sars_ppe",                          NA,                      NA,   "text",  "US",                              list(hjust = .1, overlay = TRUE)
)

column_info


column_groups <- tribble(
  ~ group,     ~ palette,      ~ level1,
  "Method",       "black",      "Method",
  "US",       "blues",         "US",
)

row_info <- tibble(id = data_plot$id, 
                   group = NA_character_)


palettes <- list(
  "Type" = c(string = "#4c4c4c", fingerprint = "#CD6889",descriptors = "66CDAA",graph = "FF7256","Graph+geometry" = "FF69B4",image = "8A2BE2",geometry = "BCEE68"),
  blues = "Blues",
  black = c("black", "black")
)



legends <- list(
  list(
    title = "US rank",
    palette = "blues",
    geom = "rect",
    labels = c("40", " ", "30", " ", "20"," ", "10", " ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  )
)



## 作图
funky_heatmap(
  data = data_plot,
  column_info = column_info,
  column_groups = column_groups,
  row_info = row_info,
  palettes = palettes,
  legends = legends,
  position_args = position_arguments(
    col_annot_offset = 4
  ),
  scale_column = FALSE
)




