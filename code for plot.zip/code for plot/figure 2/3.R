
library(tidyverse)
library(funkyheatmap)
library(kableExtra)

data<-read.table(file='F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\热图复刻数据-2-归一化.csv',header=TRUE,row.names= NULL,sep=',')
head(data)

# 构造一个函数将排名在3名之外的赋值为空
label_top_3 <- function(scores, ...) {
  ranks <- rank(scores, ...)
  ifelse(ranks <= 3, as.character(ranks), "")
}

data  %>% 
  mutate(id = as.character(1:n()),
         Type = factor(Type, 
                       levels = c("Fixed", "Learned"), 
                       labels = c("Fixed", "Learned")),
         dimension = factor(dimension,
                            levels = c("1D","2D","2D+3D","3D","1D+2D+3D"),
                            labels = c("1D","2D","2D+3D","3D","1D+2D+3D"))
  )  %>%
  
  # Create rank labels
  mutate(label_All = label_top_3(rank_All),
         label_Physiology_USI = label_top_3(rank_Physiology_USI),
         label_Biophysics_USI = label_top_3(rank_Biophysics_USI),
         label_Physical_chemistry_USI = label_top_3(rank_Physical_chemistry_USI),
         label_Quantum_mechanics_USI = label_top_3(rank_Quantum_mechanics_USI),
         label_SARS_CoV_USI = label_top_3(rank_SARS_CoV_USI),
         label_aupr = label_top_3(rank_aupr),
         label_precision = label_top_3(rank_precision),
         label_recall = label_top_3(rank_recall),
         label_f1 = label_top_3(rank_f1),
         label_muti_label_USI = label_top_3(rank_muti_label_USI),
         label_datasize_USI = label_top_3(rank_datasize_USI),
         label_time = label_top_3(rank_time)
  ) %>% 
  # scale rank columns between [0, 1] because `scale_column` is set to FALSE.
  mutate(across(c("rank_All", "rank_Physiology_USI", "rank_Biophysics_USI", "rank_Physical_chemistry_USI", "rank_Quantum_mechanics_USI", "rank_SARS_CoV_USI","rank_aupr", "rank_precision", "rank_recall", "rank_f1", "rank_muti_label_USI", "rank_datasize_USI","rank_time"),
                ~scale_minmax(-.x))) %>% 
  as_tibble() -> data_plot


column_info <- tribble(# tribble_start
  ~id,                   ~id_color,                   ~name,    ~geom,         ~group,                                                      ~options,
  "id",                          NA,                  "Index",   "text",       "Method",                                               list(hjust = 0),
  "method",                          NA,                "Method",   "text",       "Method",                                    list(hjust = 0, width = 5.2),
  "Type",                  "Type",              "Representation Type",   "text",       "Method",                         list(palette = "Type", width = 2),
  "dimension",           "dimension",             "Representation Dimension",   "text",    "Method",           list(palette = "dimension", width = 4.5),
  "All",             "rank_All",              "Over All",    "bar",          "Universality",    list(palette = "blues", width = 4.5, draw_outline = FALSE),
  "label_All",                          NA,                      NA,   "text",          "Universality",                              list(hjust = .1, overlay = TRUE),
  "Physiology_USI",           "rank_Physiology_USI",                  "Physiology",    "bar",          "Task Adaptability",    list(palette = "greens", width = 4, draw_outline = FALSE),
  "label_Physiology_USI",                          NA,                      NA,   "text",          "Task Adaptability",                              list(hjust = .1, overlay = TRUE),
  "Biophysics_USI",      "rank_Biophysics_USI",        "Biophysics",    "bar",          "Task Adaptability",    list(palette = "greens", width = 4, draw_outline = FALSE),
  "label_Biophysics_USI",                          NA,                      NA,   "text",          "Task Adaptability",                              list(hjust = .1, overlay = TRUE),
  "Physical_chemistry_USI",  "rank_Physical_chemistry_USI",  "Physical Chemistry",    "bar",          "Task Adaptability",    list(palette = "greens", width = 4, draw_outline = FALSE),
  "label_Physical_chemistry_USI",                          NA,                      NA,   "text",          "Task Adaptability",                              list(hjust = .1, overlay = TRUE),
  "Quantum_mechanics_USI",          "rank_Quantum_mechanics_USI",           "Quantum Mechanics",    "bar",          "Task Adaptability",    list(palette = "greens", width = 4, draw_outline = FALSE),
  "label_Quantum_mechanics_USI",                          NA,                      NA,   "text",          "Task Adaptability",                              list(hjust = .1, overlay = TRUE),
  "SARS_CoV_USI",      "rank_SARS_CoV_USI",                 "SARS-CoV-2",    "bar",  "Task Adaptability",   list(palette = "greens", width = 4, draw_outline = FALSE),
  "label_SARS_CoV_USI",                          NA,                      NA,   "text",  "Task Adaptability",                              list(hjust = .1, overlay = TRUE),
  "aupr",        "rank_aupr",                 "AUPR",    "bar",  "Class Imbalance",   list(palette = "oranges", width = 4, draw_outline = FALSE),
  "label_aupr",                          NA,                      NA,   "text",  "Class Imbalance",                              list(hjust = .1, overlay = TRUE),
  "precision",        "rank_precision",                 "Precision",    "bar",  "Class Imbalance",   list(palette = "oranges", width = 4, draw_outline = FALSE),
  "label_precision",                          NA,                      NA,   "text",  "Class Imbalance",                              list(hjust = .1, overlay = TRUE),
  "recall",             "rank_recall",              "Recall",    "bar",          "Class Imbalance",    list(palette = "oranges", width = 4, draw_outline = FALSE),
  "label_recall",                          NA,                      NA,   "text",          "Class Imbalance",                              list(hjust = .1, overlay = TRUE),
  "f1",           "rank_f1",                  "F1",    "bar",          "Class Imbalance",    list(palette = "oranges", width = 4, draw_outline = FALSE),
  "label_f1",                          NA,                      NA,   "text",          "Class Imbalance",                              list(hjust = .1, overlay = TRUE),
  "muti_label_USI",      "rank_muti_label_USI",        "Multi Label",    "bar",          "Multi Label",    list(palette = "greys", width = 4, draw_outline = FALSE),
  "label_muti_label_USI",                          NA,                      NA,   "text",          "Multi Label",                              list(hjust = .1, overlay = TRUE),
  "datasize_USI",  "rank_datasize_USI",  "Datasize",    "bar",          "Datasize",    list(palette = "purples", width = 4, draw_outline = FALSE),
  "label_datasize_USI",                          NA,                      NA,   "text",          "Datasize",                              list(hjust = .1, overlay = TRUE),
  "time",  "rank_time",  "Time",    "bar",          "Time",    list(palette = "reds", width = 4, draw_outline = FALSE),
  "label_time",                          NA,                      NA,   "text",          "Time",                              list(hjust = .1, overlay = TRUE)
)

column_info


column_groups <- tribble(
  ~ group,     ~ palette,      ~ level1,
  "Method",       "black",      "Method",
  "Universality",  "blues",  "Universality",
  "Task Adaptability", "greens", "Task Adaptability",
  "Class Imbalance", "oranges", "Class Imbalance",
  "Multi Label",       "greys",         "Multi Label",
  "Datasize", "purples", "Datasize",
  "Time","reds","Time"
)

row_info <- tibble(id = data_plot$id, 
                   group = NA_character_)


palettes <- list(
  Type = c(Fixed = "#6A51A3", Learned = "#006600"),
  dimension = c("1D" = "#AD1132","2D" = "#2E5698","3D" = "#592BA5","2D+3D" = "#EE7D31","1D+2D+3D"="#804000"),
  blues = RColorBrewer::brewer.pal(9, "Blues"),  # 翻转蓝色调色板，使数值大时颜色更深
  greens = RColorBrewer::brewer.pal(9, "Greens"),  # 翻转绿色调色板
  oranges = RColorBrewer::brewer.pal(9, "Oranges"),  # 翻转橙色调色板
  greys = RColorBrewer::brewer.pal(9, "Greys"),  # 翻转灰色调色板
  purples = RColorBrewer::brewer.pal(9, "Purples"),  # 翻转紫色调色板
  black = c("black", "black"),
  reds = "Reds"
)



legends <- list(
  list(
    title = "Unified Score Index",
    palette = "blues",
    geom = "rect",
    labels = c("0", " ", "0.25"," ", "0.50", " ","0.75"," ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Unified Score Index",
    palette = "greens",
    geom = "rect",
    labels = c("0", " ", "0.25"," ", "0.50", " ","0.75"," ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Precision/Recall/F1",
    palette = "oranges",
    geom = "rect",
    labels = c("0", " ", "0.25"," ", "0.50", " ","0.75"," ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Unified Score Index",
    palette = "greys",
    geom = "rect",
    labels = c("0", " ", "0.25"," ", "0.50", " ","0.75"," ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Unified Score Index",
    palette = "purples",
    geom = "rect",
    labels = c("0", " ", "0.25"," ", "0.50", " ","0.75"," ", "1"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  ),
  list(
    title = "Time",
    palette = "reds",
    geom = "rect",
    labels = c("1", " ", "0.75"," ", "0.50", " ","0.25"," ", "0"),
    size = c(1, 1, 1, 1, 1, 1, 1, 1, 1)
  )
)



## 作图
funky_heatmap(
  data = data_plot,
  column_info = column_info,
  column_groups = column_groups,
  row_info = row_info,
  palettes = palettes,
  legends = legends,
  position_args = position_arguments(
    col_annot_offset = 6
  ),
  scale_column = FALSE)


#Universality rank\Task Adaptability rank\Unbalanced rank\Muti-label rank\Sample Size rank
#labels = c("31", " ", "20"," ", "10", " ", "1"),
#size = c(1, 1, 1, 1, 1, 1, 1)
