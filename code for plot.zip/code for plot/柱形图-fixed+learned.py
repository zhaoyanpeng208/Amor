# -*- coding: utf-8 -*-
"""
Created on Thu May 22 17:43:38 2025

@author: y
"""

# -*- coding: utf-8 -*-
"""
Created on Thu May 22 17:27:25 2025

@author: y
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 读取数据（确保路径正确）
df = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\ppe-precision.csv")
y_data = df["SARS_PPE"]
x_data = df["Representations"]

# 设置两种颜色（前12个和其余柱子）
color_first_12 = '#2983B1'  # 蓝色系
color_rest = '#D37538'     # 红色系

# 绘制柱状图
plt.figure(figsize=(12, 6))  # 调整画布大小

for i in range(len(x_data)):
    if i < 12:  # 前12个柱子
        plt.bar(i, y_data[i], width=0.6, color=color_first_12, 
                edgecolor='black', alpha=0.8)
    else:  # 其余柱子
        plt.bar(i, y_data[i], width=0.6, color=color_rest, 
                edgecolor='black', alpha=0.8)

# 设置x轴标签和倾斜角度
plt.xticks(
    ticks=range(len(x_data)),
    labels=x_data,
    rotation=45,
    ha="right",
    rotation_mode="anchor",
    fontname="Arial",
    fontsize=9
)

# 添加图例
plt.bar(0, 0, color="#2983B1", label='Fixed Representation')
plt.bar(0, 0, color="#D37538", label='Learned Representation')
plt.legend(loc='upper right')

# **关键修改：增大Y轴范围**
y_max = max(y_data)
plt.ylim(0, y_max * 1.15)  # Y轴上限设为数据最大值的1.2倍

# 其他设置
plt.xlabel("Representations", fontname="Arial", fontsize=12)
plt.ylabel("SARS_PPE Precision", fontname="Arial", fontsize=12)
#plt.title("HEK293 Precision by Representations", fontname="Arial", fontsize=14)
#plt.grid(axis='y', linestyle='--', alpha=0.7)#不显示虚线
plt.tight_layout()

# 保存并显示图表
plt.savefig("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\ppe柱形图.png", dpi=600, bbox_inches="tight")
plt.show()