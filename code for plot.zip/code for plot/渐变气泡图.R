# 加载必要的库
library(ggplot2)
library(tidyr)
library(dplyr)
library(tibble)
# 读取 CSV 文件，假设第一列是行名，第一行为列名
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\SARS\\SARS-气泡-US-归一化.csv", row.names = 1)  # 替换为你的CSV文件路径

# 查看数据的格式
head(data)

# 转换数据格式，从宽格式转为长格式
long_data <- data %>%
  rownames_to_column(var = "RowName") %>%  # 将行名转换为列
  pivot_longer(cols = -RowName, names_to = "Column", values_to = "Value")  # 宽格式转为长格式

# 确保 Value 列是数值型
long_data$Value <- as.numeric(long_data$Value)

# 绘制气泡图
ggplot(long_data, aes(x = Column, y = RowName, size = Value, fill = Value)) +
  geom_point(shape = 21, color = "black", alpha = 0.7) +  # 形状21表示有填充颜色的圆形
  scale_size_continuous(range = c(3, 10)) +  # 设置气泡大小范围
  scale_fill_gradient(low = "white", high = "pink") +  # 设置颜色渐变，值越大颜色越深
  labs(x = "SARS-CoV-2", y = "Unified Score", size = "Value", fill = "Value") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5),
        panel.spacing = unit(0.01, "lines")) +
  coord_fixed(ratio = 0.5)
