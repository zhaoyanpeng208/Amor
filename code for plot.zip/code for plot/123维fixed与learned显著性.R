# 设置较宽的绘图窗口
windows(width = 15, height = 10)

# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\123维.csv")

# 查看数据
head(data)

# 绘制箱线图
boxplot(Value ~ Group, data = data,
        boxwex = 0.5,
        main = "Comparison of Fixed and Learned Representations",
        xlab = "Different Dimensional Fixed and Learned Representations",
        ylab = "USI",
        col = c("lightblue", "#99ccff", "lightgreen", "#66cc99", "#9370db", "#6a0dad"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        names = c("1D_fixed", "1D_learned", "2D_fixed", "2D_learned", "3D_fixed", "3D_learned"),
        cex.lab = 1,
        ylim = c(min(data$Value), max(data$Value) + 2))  

# 添加数据点
stripchart(Value ~ Group, data = data, 
           vertical = TRUE, 
           method = "jitter", 
           add = TRUE, 
           pch = 16, 
           col = "black")  # 数据点的颜色

# 提取组数据
group2 <- data$Value[data$Group == "1D_learned"]
group3 <- data$Value[data$Group == "2D_fixed"]
group4 <- data$Value[data$Group == "2D_learned"]
group5 <- data$Value[data$Group == "3D_fixed"]
group6 <- data$Value[data$Group == "3D_learned"]

# 进行t检验（假设比较组为后四组）
t_test1 <- t.test(group2, group3)
t_test2 <- t.test(group3, group4)
t_test3 <- t.test(group4, group5)
t_test4 <- t.test(group5, group6)

# 显示显著性结果
# 根据p值确定显著性标记
p_value1 <- t_test1$p.value
p_value2 <- t_test2$p.value
p_value3 <- t_test3$p.value
p_value4 <- t_test4$p.value

# 设置显著性标记
significance1 <- ifelse(p_value1 < 0.001, "***", ifelse(p_value1 < 0.01, "**", ifelse(p_value1 < 0.05, "*", "n.s.")))
significance2 <- ifelse(p_value2 < 0.001, "***", ifelse(p_value2 < 0.01, "**", ifelse(p_value2 < 0.05, "*", "n.s.")))
significance3 <- ifelse(p_value3 < 0.001, "***", ifelse(p_value3 < 0.01, "**", ifelse(p_value3 < 0.05, "*", "n.s.")))
significance4 <- ifelse(p_value4 < 0.001, "***", ifelse(p_value4 < 0.01, "**", ifelse(p_value4 < 0.05, "*", "n.s.")))

# 添加显著性标记到箱线图
# 添加星号标记
max_y <- max(data$Value) + 0.5  # 选择统一的高度，可以调整以适应实际数据

# 添加显著性标记到箱线图
text(x = c(2.5, 3.5, 4.5, 5.5), y = rep(max_y + 1, 4), 
     labels = c(significance1, significance2, significance3, significance4), cex = 1.5, pos = 3)

# 添加连接线
arrows(x0 = 2.2, y0 = max_y + 1, x1 = 3, y1 = max_y + 1, 
       angle = 90, code = 3, length = 0.1)
arrows(x0 = 3.2, y0 = max_y + 1, x1 = 4, y1 = max_y + 1, 
       angle = 90, code = 3, length = 0.1)
arrows(x0 = 4.2, y0 = max_y + 1, x1 = 5, y1 = max_y + 1, 
       angle = 90, code = 3, length = 0.1)
arrows(x0 = 5.2, y0 = max_y + 1, x1 = 6, y1 = max_y + 1, 
       angle = 90, code = 3, length = 0.1)