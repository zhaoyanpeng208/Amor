# -*- coding: utf-8 -*-
"""
Created on Fri Oct 25 21:05:06 2024

@author: y
"""

from scipy.stats import hypergeom

# 参数设置
N = 31  # 背景集中元素总数
K = 5   # 背景集中具有特征的元素数
n = 19    # 样本集中元素总数
x = 6    # 样本集中具有特征的元素数

# 计算p值
p_value = hypergeom.sf(x - 1, N, K, n)

print("显著性p值：", p_value)
