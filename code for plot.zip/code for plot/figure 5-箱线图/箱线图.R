windows(width = 15, height = 8)  # 设定较宽的绘图窗口

# 1. 读取CSV文件，假设文件名为 "data.csv"
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\箱线图-混合表示.csv", header = TRUE)

# 2. 排除第一列（假设第一列是非数值数据）
data_subset <- data[, -1]

# 3. 创建颜色向量，为每个箱线图指定一个不同的颜色
colors <- rainbow(ncol(data_subset))  # 使用 rainbow() 函数生成颜色向量


# 4. 绘制箱线图，为每个对象使用不同的颜色
boxplot(data_subset, 
        main = "Performance comparison of hybrid representations",  # 图表标题
        #xlab = "Representation",                      # X轴标签
        #ylab = "Unified Score",                       # Y轴标签
        col = colors,                          # 设置每个箱子不同颜色
        las = 2,                              # 设置每个箱子不同颜色
        xaxt = "n",                              # 使X轴标签垂直显示
        border = "darkblue",                   # 设置箱线图边框颜色
        notch = FALSE)                          # 设置凹槽，表示置信区间

axis(1, at = 1:ncol(data_subset), labels = FALSE)   # 禁止刻度显示

# 5. 使用 text() 函数倾斜标签
text(x = 1:ncol(data_subset), y = par("usr")[3] - 0.5, 
     labels = colnames(data_subset), 
     srt = 0,        # 45度倾斜
     adj = 0.5,         # 标签对齐方式
     xpd = TRUE,      # 标签显示在绘图区域之外
     cex = 0.8)  

# 手动添加X轴和Y轴标题
mtext("Representation", side = 1, line = 2)  # 你可以调整 line 参数以X轴标题改变位置
mtext("Unified Score", side = 2, line = 2)   # 你可以调整 line 参数以Y轴标题改变位置

# 6. 添加数据点到箱线图中
stripchart(data_subset, 
           vertical = TRUE, 
           method = "jitter",  # 添加抖动以避免数据点重叠
           pch = 16,           # 数据点的形状
           col = "black",       # 数据点颜色
           add = TRUE)         # 在箱线图上添加数据点
legend("bottom", bty = "n", inset = c(0, -0.93), legend = colnames(data_subset), fill = colors, lty = 1, lwd = 2, pch = 16,ncol=2)

# 5. 添加图例（可选）
legend("topright", legend = colnames(data_subset), fill = colors, title = "Different Representation", inset = c(-0.3, 0))
