#windows(width = 15, height = 8)  # 设定较宽的绘图窗口

# 设置边距以缩小图形宽度
par(mar = c(5, 3, 4, 0.3))  # 调整边距：底部、左侧、顶部、右侧

# 1. 读取CSV文件，假设文件名为 "data.csv"
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\二维比较.csv", header = TRUE)

# 2. 排除第一列（假设第一列是非数值数据）
data_subset <- data[, -1]

# 3. 创建颜色向量，为每个箱线图指定一个不同的颜色
colors <- c(colorRampPalette(c("#9370DB"))(9), #前3个使用红色渐变
            colorRampPalette(c("lightgreen"))(12))  # 后10个使用蓝色渐变   

# 4. 绘制箱线图，为每个对象使用不同的颜色
boxplot(data_subset, 
        main = "Comparison of two-dimensional fixed and learned representation",  # 图表标题
        #xlab = "Representation",                      # X轴标签
        #ylab = "Unified Score",                       # Y轴标签
        col = colors,                          # 设置每个箱子不同颜色
        las = 2,                              # 设置每个箱子不同颜色
        xaxt = "n",                              # 使X轴标签垂直显示
        border = "darkblue",                  #设置箱线图边框颜色
        boxwex = 0.5,
        notch = FALSE)                          # 设置凹槽，表示置信区间

axis(1, at = 1:ncol(data_subset), labels = FALSE)   # 禁止刻度显示

# 5. 使用 text() 函数倾斜标签
text(x = 1:ncol(data_subset), y = par("usr")[3] - 0.5, 
     labels = colnames(data_subset), 
     srt = 10,        # 45度倾斜
     adj = 1,         # 标签对齐方式
     xpd = TRUE,      # 标签显示在绘图区域之外
     cex = 0.8)  

# 手动添加X轴和Y轴标题
mtext("two dimensional fixed and learned rpresentation", side = 1, line = 3)  # 你可以调整 line 参数以X轴标题改变位置
mtext("Unified Score", side = 2, line = 2)   # 你可以调整 line 参数以Y轴标题改变位置

# 6. 添加数据点到箱线图中
stripchart(data_subset, 
           vertical = TRUE, 
           method = "jitter",  # 添加抖动以避免数据点重叠
           pch = 16,           # 数据点的形状
           col = "black",       # 数据点颜色
           add = TRUE)         # 在箱线图上添加数据点

legend("topleft",
       bty = "n", # 去掉图例的边框
       legend = c("2D_fixed","2D_learned"),
       fill = c("#9370DB","lightgreen"), ncol=1)

# 5. 添加图例（可选）
#legend("topright", legend = colnames(data_subset), fill = colors, title = "Different Representation", inset = c(-0.62, 0))
