# -*- coding: utf-8 -*-
"""
Created on Wed Jan  8 20:06:28 2025

@author: y
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jun 12 16:40:54 2023

@author: DELL
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

f=open("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\特殊数据集\\差向异构.csv")
df=pd.read_csv(f)

y_data=df["value"]
x_data=df["Category"]

#colors = ['#DC645F', '#ECA164', '#FCDCB0', '#66AFC5', '#426A93',"#6A51A3","#7F7DBA","#C1927F"]  # 可以根据需要增加颜色
colors = ['#ECA164','#66AFC5', '#66AFC5', '#66AFC5', '#66AFC5',"#7F7DBA","#7F7DBA","#7F7DBA"]

for i in range(len(x_data)):
    plt.bar(x_data[i],y_data[i],width=0.5,color=colors[i % len(colors)])
    
for i,v in enumerate(y_data):
    plt.annotate(str(v),xy=(i,v), ha='center', va='bottom',fontproperties='Arial')

plt.xticks(x_data, x_data, rotation=0,fontname='Arial',fontsize=9)#设置x轴坐标倾斜
plt.yticks(fontname='Arial')
plt.xlabel("Representations",fontname='Arial',fontsize=12)
plt.ylabel("Number of Predicted  Correct Pairs ↑",fontname='Arial',fontsize=12)

plt.savefig("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\特殊数据集\\差向异构柱形图",dpi=400,bbox_inches='tight')
