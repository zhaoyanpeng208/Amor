# 设置较宽的绘图窗口
par(mar = c(5, 4, 4, 17), mgp = c(2.5, 1, 0))  # 调整边距：底部、左侧、顶部、右侧

# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\123维.csv")



# 绘制箱线图
boxplot(Value ~ Group, data = data,
        main = "Comparison of Fixed and Learned Representations on different dimension",
        boxwex = 0.4,
        xlab = "",
        ylab = "USI",
        col = c("#EEA164","#DC645F","#E78657","#99D2D5","#568BA4","#436A93"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        xaxt = "n",  # 禁止默认的X轴标签
        border = "black",                  # 设置箱线图边框颜色
        medcol = "black",                  # 中位数线的颜色
        whiskcol = "black",                # 胡须的颜色
        staplecol = "black",               # 极值线的颜色
        outcol = "black",                  # 异常值颜色
        lty = 1,
        cex.axis = 1.1,                    # 刻度标签的字体大小
        cex.lab = 1.2,
        cex.main = 1.2)

# 使用 axis() 和 text() 函数手动添加X轴标签并倾斜显示
axis(1, at = 1:6, labels = FALSE)  # 隐藏默认X轴标签
text(x = 1:6, y = par("usr")[3] - 2.5, 
     labels = c("1D Fixed", "1D Learned", "2D Fixed", "2D Learned", "3D Fixed", "3D Learned"),
     srt = 45,   # 设置倾斜角度
     adj = 1,    # 调整对齐方式，确保标签不会重叠
     xpd = TRUE, # 确保标签不会被裁剪
     cex = 1.1)  # 调整标签的字体大小
