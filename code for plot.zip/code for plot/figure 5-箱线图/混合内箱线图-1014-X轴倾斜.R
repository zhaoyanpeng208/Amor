# 设置较宽的绘图窗口
par(mar = c(5, 4, 4, 15), mgp = c(2.5, 1, 0))  # 调整边距：底部、左侧、顶部、右侧

# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\箱线图-混合表示.csv")

# 排除第一列（假设第一列是非数值数据）
data_subset <- data[, -1]  # 去掉第一列

# 绘制箱线图
boxplot(data_subset,
        main = "Comparison of Hybrid Representations",
        boxwex = 0.4,
        ylab = "US",
        col = c("#DC645F","#E78657","#E78657","#99D2D5","#99D2D5","#568BA4","#436A93"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        xaxt = "n",  # 禁止默认的X轴标签
        border = "black",                  # 设置箱线图边框颜色
        medcol = "black",                  # 中位数线的颜色
        whiskcol = "black",                # 胡须的颜色
        staplecol = "black",               # 极值线的颜色
        outcol = "black",                  # 异常值颜色
        lty = 1,
        cex.axis = 1.2,                    # 刻度标签的字体大小
        cex.lab = 1.3,
        cex.main = 1.5)

# 使用 axis() 和 text() 函数手动添加X轴标签并倾斜显示
axis(1, at = 1:ncol(data_subset), labels = FALSE)  # 隐藏默认X轴标签
text(x = 1:ncol(data_subset), y = par("usr")[3] - 1.2, 
     labels = c("MolMapNet",	"3D Infomax",	"Graphmvp",	"KANO",	"KPGT",	"PremuNet",	"PharmHGT"),
     srt = 45,   # 设置倾斜角度
     adj = 1,    # 调整对齐方式，确保标签不会重叠
     xpd = TRUE, # 确保标签不会被裁剪
     cex = 1.2)  # 调整标签的字体大小
