windows(width = 15, height = 10)  # 设定较宽的绘图窗口

# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\预训练USI-TOP5.csv")


# 查看数据
head(data)
# 绘制箱线图
boxplot(Value ~ Group, data = data,
        boxwex = 0.5,
        main = "Comparison of pre-training and others representations",
        xlab = "pre-training and others representations",
        ylab = "USI",
        col = c("#DC645F","#436A93"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        names = c("Others","pre-training"),
        cex.lab = 1,
        ylim = c(min(data$Value), y_max + 2))  
#"lightblue","#87CEFA","lightgreen","green","#9370DB","purple"
# 添加数据点
stripchart(Value ~ Group, data = data, 
           vertical = TRUE, 
           method = "jitter", 
           add = TRUE, 
           pch = 16, 
           col = "black")  # 数据点的颜色

# 进行 t 检验以比较组间的显著性
t_test_result <- t.test(Value ~ Group, data = data)

# 手动添加显著性标记
p_value <- t_test_result$p.value

# 添加显著性线和星号
y_max <- max(data$Value)  # 找到数据的最大值，方便放置显著性标记
segments(1, y_max + 1, 2, y_max + 1)  # 在箱线图上方画一条水平线
text(1.5, y_max + 1.5, labels = ifelse(p_value < 0.05, "*", "n.s."), cex = 1.5)  # 根据p值添加星号

# 输出 t 检验的结果
print(t_test_result)