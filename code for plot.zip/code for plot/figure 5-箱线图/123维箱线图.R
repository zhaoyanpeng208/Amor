# 设置较宽的绘图窗口
windows(width = 12, height = 10)

# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\123维.csv")

# 查看数据
head(data)

# 绘制箱线图
boxplot(Value ~ Group, data = data,
        boxwex = 0.4,
        main = "Comparison of Fixed and Learned Representations",
        xlab = "Different Dimensional Fixed and Learned Representations",
        ylab = "USI",
        col = c("#EEA164","#DC645F","#E78657","#99D2D5","#568BA4","#436A93"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        names = c("1D_fixed", "1D_learned", "2D_fixed", "2D_learned", "3D_fixed", "3D_learned"),
        cex.lab = 1,
        ylim = c(min(data$Value), max(data$Value) + 2))  

# 添加数据点
stripchart(Value ~ Group, data = data, 
           vertical = TRUE, 
           method = "jitter", 
           add = TRUE, 
           pch = 16, 
           col = "black")  # 数据点的颜色

