windows(width = 15, height = 8)  # 设定较宽的绘图窗口
# Step 1: 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\一维比较.csv", header = TRUE, row.names = 1)

# Step 2: 转换数据格式为长格式 (使用tidyr包)
library(tidyr)
long_data <- pivot_longer(data, cols = everything(), names_to = "Group", values_to = "Value")

# Step 3: 定义颜色
# 前10个对象使用一个色系，后3个对象使用另一个色系
colors <- c(colorRampPalette(c("#FFC0CB", "#FF69B4"))(3), #前3个使用红色渐变
            colorRampPalette(c("lightblue", "#4169E1"))(10))  # 后10个使用蓝色渐变   

par(mar = c(7, 4, 4, 2))  # 增大底部边距，mar的顺序为：底，左，顶，右

# Step 4: 绘制箱线图
boxplot(Value ~ Group, data = long_data, col = colors,
        cex.axis = 0.7,
        outline = FALSE, #不会显示异常数据点
        boxwex = 0.5, #boxwex：用于控制箱子的宽度。默认值为1
        main = "Comparison of fixed representation with learned representation", xlab = "Fixed and learned representations", ylab = "Unified Score")
          # 调整字体大小

# 使用 stripchart() 显示数据点
#stripchart(Value ~ Group, data = long_data, 
#           vertical = TRUE,    # 垂直显示
#           method = "jitter",  # 添加抖动，避免数据点重叠
#           pch = 16,           # 数据点形状，16 为实心圆
#           col = "black",      # 数据点颜色
#           add = TRUE)         # 添加到现有的箱线图上
# 添加图例
#legend("topright", legend = colnames(data), fill = colors, title = "Groups")
