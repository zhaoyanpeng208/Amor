# 设置较宽的绘图窗口
#windows(width = 3, height = 10)
par(mar = c(5, 4, 4, 8),mgp = c(2.5, 1, 0))  # 调整边距：底部、左侧、顶部、右侧
# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\123维.csv")

# 查看数据
head(data)

# 绘制箱线图
boxplot(Value ~ Group, data = data,
        boxwex = 0.4,
        main = "Comparison of Fixed and Learned Representations on different dimension",
        #xlab = "Different Dimensional Fixed and Learned Representations",
        ylab = "USI",
        col = c("#EEA164","#DC645F","#E78657","#99D2D5","#568BA4","#436A93"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        names = c("1D Fixed", "1D Learned", "2D Fixed", "2D Learned", "3D Fixed", "3D Learned"),
        cex.lab = 1.3,
        ylim = c(min(data$Value), max(data$Value) + 2),
        border = "black",                  #设置箱线图边框颜色
        medcol = "black",    # 中位数线的颜色
        whiskcol = "black",  # 胡须的颜色
        staplecol = "black", # 极值线（箱线图两端T形）的颜色
        outcol = "black",
        lty = 1,
        cex.axis = 1.2,# 刻度标签的字体大小
        cex.main = 1.5)  # 标题的字体大小


