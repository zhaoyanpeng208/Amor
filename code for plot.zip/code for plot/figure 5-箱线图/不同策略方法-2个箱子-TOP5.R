#windows(width = 8, height = 10)  # 设定较宽的绘图窗口
par(mar = c(5, 5, 8, 11),mgp = c(2, 0.7, 0))  # 调整 mgp，第一个值控制轴标签距离
# 读取CSV文件
data <- read.csv("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\混合USI-TOP5.csv")


# 查看数据
head(data)
# 计算 y 轴的最大值
y_max <- max(data$Value)
# 绘制箱线图
boxplot(Value ~ Group, data = data,
        boxwex = 0.3,# 设置箱子的宽度
        #main = "Fixed VS Learned Representations",
        #xlab = "Fixed and Learned representations",
        ylab = "USI",
        col = c("#436A93","#DC645F"),  # 自定义颜色
        notch = FALSE,  # 如果需要显示凹槽
        names = c("Hybrid","Others"),
        cex.lab = 1.1,
        cex.axis = 1,
        lty = 1,
        ylim = c(min(data$Value), y_max + 2))  
#"lightblue","#87CEFA","lightgreen","green","#9370DB","purple"

# 添加标题，并调整标题与图的距离
title(main = "Hybrid  VS. Others\n(TOP5)", 
      line = 1,  # 调整此值让标题更接近图形
      cex.main = 1)  # 设置标题的字体大小

# 进行 U 检验以比较组间的显著性
t_test_result <- wilcox.test(Value ~ Group, data = data)

# 手动添加显著性标记
p_value <- t_test_result$p.value

# 添加显著性线和星号
y_max <- max(data$Value)  # 找到数据的最大值，方便放置显著性标记
segments(1, y_max + 1, 2, y_max + 1)  # 在箱线图上方画一条水平线
text(1.5, y_max + 1.8, labels = ifelse(p_value < 0.05, "*", "n.s."), cex = 1.5)  # 根据p值添加星号

# 输出 t 检验的结果
print(t_test_result)
