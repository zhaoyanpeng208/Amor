# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 14:29:31 2024

@author: y
"""

import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 1. 读取CSV文件
file_path = 'F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\热图复刻数据-2 - 副本.csv'  # 替换为你的文件路径
df = pd.read_csv(file_path)

# 2. 创建一个MinMaxScaler实例，将数据初步缩放到[0, 1]范围
scaler = MinMaxScaler()

# 3. 对每一列进行归一化，同时忽略零值
#    选择数值型列进行处理
numeric_columns = df.iloc[:,1:15].select_dtypes(include=['float64', 'int64']).columns

# 创建一个新的数据框用于存储归一化结果
normalized_df = df.copy()

# 小偏移量，避免达到0或1
epsilon = 1e-6

for col in numeric_columns:
    non_zero_mask = df[col] != 0  # 创建一个掩码，标记非零值
    non_zero_values = df.loc[non_zero_mask, col].values.reshape(-1, 1)
    
    if non_zero_values.size > 0:  # 检查是否有非零值
        # 初步归一化到[0, 1]
        normalized_values = scaler.fit_transform(non_zero_values).flatten()
        
        # 调整归一化结果到(0, 1)
        normalized_values = normalized_values * (1 - 2 * epsilon) + epsilon
        
        # 更新归一化后的数据
        normalized_df.loc[non_zero_mask, col] = normalized_values

# 4. 打印归一化后的数据
print(normalized_df.head())

# 5. 将归一化后的数据保存到一个新的CSV文件中（可选）
normalized_df.to_csv('F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\热图复刻数据-2-归一化-logtime.csv', index=False)
