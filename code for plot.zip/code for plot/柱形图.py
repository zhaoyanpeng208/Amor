# -*- coding: utf-8 -*-
"""
Created on Thu May 22 17:27:25 2025

@author: y
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np

# 读取数据（确保路径正确）
df = pd.read_csv(r"F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\9种预训练.csv")
y_data = df["USI"]
x_data = df["Model-Fingerprint"]

# 手动为每个表征指定颜色（示例颜色，可根据需要修改）
#混合
color_map = {
    "Molmapnet": "#2983B1", "PharmHGT": "#2983B1"
}

#预训练
color_map = {
    "Unimol": "#2983B1", "KPGT": "#2983B1", "MoLFormer":"#2983B1","Premunet":"#2983B1","ImageMol":"#2983B1"
}



# 确保所有表征都有对应的颜色
default_color = "#D37538"  # 未指定颜色时的默认值
colors = [color_map.get(name, default_color) for name in x_data]


# 绘制柱状图（用索引定位x轴，避免乱序）
plt.figure(figsize=(7, 4))  # 调整画布大小
for i in range(len(x_data)):
    plt.bar(i, y_data[i], width=0.5, color=colors[i])

# **关键修改：强制设置x轴标签倾斜**
plt.xticks(
    ticks=range(len(x_data)),  # 标签位置用索引
    labels=x_data,              # 标签文本
    rotation=0,                # 倾斜角度（度数）
    ha="center",                 # 右对齐避免重叠
    rotation_mode="anchor",     # 固定锚点防止偏移
    fontname="Arial",           # 字体
    fontsize=8
)

# 其他设置
plt.xlabel("Pre-training Representations", fontname="Arial", fontsize=11)
plt.ylabel("USI", fontname="Arial", fontsize=11)
plt.tight_layout()  # 自动调整布局
# 添加图例
plt.bar(0, 0, color="#2983B1", label='Generative Pre-training')
plt.bar(0, 0, color="#D37538", label='Contrastive Pre-training')
plt.legend(loc='upper right',fontsize=5)
#Generative Pre-training\Contrastive Pre-training

# 保存并显示图表
plt.savefig("F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\不同策略\\9种预训练柱形图.png", dpi=600, bbox_inches="tight")
plt.show()