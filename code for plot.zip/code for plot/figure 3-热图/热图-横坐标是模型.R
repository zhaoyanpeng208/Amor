
library("pheatmap")
library("RColorBrewer")
library("ggplot2")

data<-read.table(file='F:\\化合物分子表征\\测评方法\\1-画图\\20240820-绘图-数据\\热图数据\\fig3-热图归一化.csv',header=TRUE,row.names= 1,sep=',')
head(data)


#列注释信息
ann_col = data.frame(Model.Type=factor(c(rep("1D fixed",1), rep("1D learned",2), rep("2D fixed",9), rep("2D learned",12), rep("3D fixed",2), rep("3D learned", 5))))#创建分组行
#ann_col = data.frame(model_type=factor(c(rep("molecule fingerprint",9), rep("molecular descriptors",2), rep("string",1), rep("SMILES-based",1), rep("fingerprint-based",1), rep("molecule graph", 7), rep("molecule image",1), rep("three-dimensional structure",1), rep("mixed representation",2))))#创建分组行

#ann_col = data.frame(datasets_type=factor(c(rep("Physiology",5),rep("Biophysics",3),rep("Physical Chemistry",3),rep("Quantum Mechanics",2),rep("SARS-CoV-2",4))))#创建分组列
#行注释信息
#ann_row = data.frame(model_type=factor(c(rep("path-based fingerprint",1), rep("substructure keys-based fingerprint",2), rep("circular fingerprint",3), rep("three-dimensional fingerprint",2), rep("molecular descriptors",2), rep("SMILES-based",1), rep("don't know",1), rep("smiles+embedding",1), rep("molecular fingerprint+embedding", 1),rep("graph+embedding",3),rep("graph+end-to-end",3),rep("graph+pretrain",1),rep("Image+pretrain",1),rep("geometry+embedding",1),rep("geometry+pretrain",2))))#创建分组行
ann_row = data.frame(Datasets.Type=factor(c(rep("Physiology",5),rep("Biophysics",3),rep("Physical Chemistry",3),rep("Quantum Mechanics",2),rep("SARS-CoV-2",4))))#创建分组行

#ann_row = data.frame(datasets_type=factor(c(rep("SARS-CoV-2",4))))

row.names(ann_col) = colnames(data) #这一行必须有，否则会报错：Error in check.length("fill") :  'gpar' element 'fill' must not be length 0
row.names(ann_row) = rownames(data)

datasets_color <- c("Quantum Mechanics"="#707070", "Physical Chemistry"="#6850A3", Biophysics="#DC4800",Physiology="#144C86", "SARS-CoV-2"="#BF0000")
#model_color <- c("path-based fingerprint"="red","substructure keys-based fingerprint"="#EE7700","circular fingerprint"="#EEEE00","three-dimensional fingerprint"="#0066FF","molecular descriptors"="#B94FFF","SMILES-based"="#FF77FF","don't know"="#888888",'smiles+embedding'='#8B0000','molecular fingerprint+embedding'='#FF7744','graph+embedding'='#009900','graph+end-to-end'='#00CC00','graph+pretrain'='#66FF00','Image+pretrain'='#BBFF66','geometry+embedding'='#00BBFF','geometry+pretrain'='#77DDFF')
model_color <- c("1D fixed"="#F1B6DA","1D learned"="#A6DBA0","2D fixed"="#FA9FB5","2D learned"="#5AAE61","3D fixed"="#DE77AE","3D learned"="#1A9850")

ann_colors <- list(Datasets.Type=datasets_color,Model.Type=model_color)


figure=pheatmap(data,cluster_rows = F,cluster_cols = F, #cluster_rows表示仅对行聚类，cluster_cols表示仅对列聚类，值为TRUE或FALSE
                
                cutree_rows = NA, cutree_cols = NA, #若进行了行/列聚类，根据行/列聚类数量分隔热图行,cutree_rows=num分割行，cutree_cols=num分割列
                
                treeheight_row = 30, treeheight_col = 30, #若行、列聚类树高度调整
                
                border_color = "grey60", #表示热图每个小的单元格边框的颜色，默认为 "grey60"
                
                cellwidth = 20, cellheight = 20,  #表示单个单元格的宽度\高度，默认为 “NA”
                
                display_numbers = T, #表示是否在单元格上显示原始数值或按照特殊条件进行区分标记
                
                fontsize_number = 6, #表示热图上显示数字的字体大小
                
                number_format = "%.2f", #表示热图单元格上显示的数据格式，“%.2f” 表示两位小数,“%.1e”表示科学计数法
                
                number_color = "black", #表示热图单元格上显示的数据字体颜色
                
                fontsize =10, fontsize_row = 10, fontsize_col = 10,fontfamily= "Times New Roman", #热图中字体大小、行、列名字体大小
                
                show_rownames = T, show_colnames = T, #表示是否显示行名、列名
                
                #main = "Gene标题", #表示热图的标题名字
                
                #color = colorRampPalette(c("navy","white","firebrick3"))(100), #表示热图颜色,(100)表示100个等级
                
                color = colorRampPalette(c("white","#C7E9C0","#238B45"))(100),
                
                angle_col = "90", #表示列标签的角度
                
                gaps_col = c(1,3,12,24,26),  #仅在未进行行聚类时使用，表示在行方向上热图的隔断位置
                gaps_row = c(5,8,11,13),
                
                annotation_row = ann_row, annotation_col = ann_col, #表示是否对行、列进行注释，默认NA
                
                annotation = NA, annotation_colors = ann_colors,  #表示行注释及列注释的颜色，默认NA
                
                annotation_legend = TRUE, #表示是否显示注释的图例信息
                
                annotation_names_row = TRUE, annotation_names_col = TRUE,
                legend = F)


filename='F:\\11454横坐标是模型'
ggsave(figure,filename=paste0(filename,".png"),width=14,height=8,dpi=400,device="png")
